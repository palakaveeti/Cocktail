package com.example.vignesh.cocktail;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.vignesh.cocktail.json.AlcoholPojo;
import com.squareup.picasso.Picasso;

import java.util.List;

public class AlcoholAdapter extends RecyclerView.Adapter<AlcoholAdapter.ViewHolder> {
    List<AlcoholPojo> alcoholPojoList;
    Context context;

    public AlcoholAdapter(Context context, List<AlcoholPojo> alcoholPojoList) {
        this.context = context;
        this.alcoholPojoList = alcoholPojoList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.alcohol_list, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Picasso.with(context).load(alcoholPojoList.get(position).getImage()).into(holder.image_home);
        holder.text_home.setText(alcoholPojoList.get(position).getName());

    }

    @Override
    public int getItemCount() {
        return alcoholPojoList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView image_home;
        TextView text_home;

        public ViewHolder(View itemView) {
            super(itemView);
            image_home = itemView.findViewById(R.id.image_list);
            text_home = itemView.findViewById(R.id.name_list);
            image_home.setOnClickListener(this);

        }

        @Override
        public void onClick(View view) {
            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("ids", alcoholPojoList.get(getAdapterPosition()).getId());
            intent.putExtra("name", alcoholPojoList.get(getAdapterPosition()).getName());
            intent.putExtra("image", alcoholPojoList.get(getAdapterPosition()).getImage());
            context.startActivity(intent);
        }
    }
}
