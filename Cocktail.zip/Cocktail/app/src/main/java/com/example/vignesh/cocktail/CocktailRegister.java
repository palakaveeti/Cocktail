package com.example.vignesh.cocktail;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class CocktailRegister extends AppCompatActivity {
    EditText email, password;


    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cocktail_register);
        mAuth = FirebaseAuth.getInstance();
        email = findViewById(R.id.emai_register);
        password = findViewById(R.id.password_register);
    }

    public void registerReg(View view) {
        if (!TextUtils.isEmpty(email.getText().toString().trim())) {
            if (!TextUtils.isEmpty(password.getText().toString())) {
                mAuth.createUserWithEmailAndPassword(email.getText().toString(), password.getText().toString())
                        .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Intent intent = new Intent(CocktailRegister.this, CocktailLogin.class);
                                    startActivity(intent);
                                    Toast.makeText(CocktailRegister.this, R.string.successinregister, Toast.LENGTH_SHORT).show();

                                } else {
                                    // If sign in fails, display a message to the user.
                                    Toast.makeText(CocktailRegister.this, R.string.authenticationinregister,
                                            Toast.LENGTH_SHORT).show();

                                }

                            }
                        });
            } else {
                Toast.makeText(this, R.string.enterpassinreg, Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, R.string.enterpasswordinreg, Toast.LENGTH_SHORT).show();
        }


    }
}
