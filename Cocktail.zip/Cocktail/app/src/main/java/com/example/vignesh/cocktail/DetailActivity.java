package com.example.vignesh.cocktail;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.vignesh.cocktail.cocktailwidget.CocktailWidget;
import com.example.vignesh.cocktail.json.AlcoholPojo;
import com.example.vignesh.cocktail.json.DetailParsing;
import com.example.vignesh.cocktail.roomdatabase.RoomData;

import java.util.List;

public class DetailActivity extends AppCompatActivity {
    ImageView detailImage;
    TextView Name, Category, typeofdrink, glass, instruction, manufatureddate, iba;
    int ID;
    String url1 = "https://www.thecocktaildb.com/api/json/v1/1/lookup.php?i=";
    Button favorate;
    String Namee, Imagee;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        detailImage = findViewById(R.id.imageDetail);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Name = findViewById(R.id.nameDetail);
        Category = findViewById(R.id.categoryDetail);
        typeofdrink = findViewById(R.id.alcoholornot);
        glass = findViewById(R.id.glassDetail);
        instruction = findViewById(R.id.innstructionsDetail);
        manufatureddate = findViewById(R.id.manufatureDate);
        favorate = findViewById(R.id.fa_icon);
        iba = findViewById(R.id.iba);

        Intent intent = getIntent();
        ID = intent.getIntExtra("ids", 0);
        Namee = intent.getStringExtra("name");
        Imagee = intent.getStringExtra("image");
        String detailurl = url1 + ID;
        DetailParsing detaiParsing = new DetailParsing(detailurl, DetailActivity.this, detailImage,
                Name, Category, typeofdrink, glass, instruction, manufatureddate, iba);
        detaiParsing.getDetails();
        Toast.makeText(this, "" + ID, Toast.LENGTH_SHORT).show();

        AlcoholPojo s = RoomData.getDrinkData(this).mydao().selectedDrinkDat(ID);
        if (s != null) {
            favorate.setBackgroundResource(R.drawable.ic_star_black_24dp);

        } else {
            favorate.setBackgroundResource(R.drawable.ic_star_border_black_24dp);
        }


    }

    public void click(View view) {

        AlcoholPojo que = RoomData.getDrinkData(this).mydao().selectedDrinkDat(ID);
        if (que != null) {
            RoomData.getDrinkData(this).mydao().deleteAllDrinks(que);
            favorate.setBackgroundResource(R.drawable.ic_star_border_black_24dp);

        } else {
            AlcoholPojo que1 = new AlcoholPojo();
            que1.setId(ID);
            que1.setName(Namee);
            que1.setImage(Imagee);

            RoomData.getDrinkData(this).mydao().insertDrink(que1);
            favorate.setBackgroundResource(R.drawable.ic_star_black_24dp);


            Toast.makeText(this, R.string.favouritemessage, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.widgetmenu, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        } else if (id == R.id.widget) {
            CocktailWidget.setWidget(this, Name.getText().toString(), typeofdrink.getText().toString());
        } else if (id == R.id.feedback) {
            Intent intent = new Intent(this, CocktailFeedback.class);
            startActivity(intent);

        }
        return super.onOptionsItemSelected(item);
    }
}

