package com.example.vignesh.cocktail;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.vignesh.cocktail.json.AlcoholParsing;
import com.example.vignesh.cocktail.json.AlcoholPojo;
import com.example.vignesh.cocktail.roomdatabase.Modelclass;

import java.util.List;

public class MainActivity extends AppCompatActivity implements SharedPreferences.OnSharedPreferenceChangeListener {
    String alcoholUrl = "https://www.thecocktaildb.com/api/json/v1/1/filter.php?a=";
    String typeofdrink;
    String string;
    RecyclerView drink_recyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        drink_recyclerView = findViewById(R.id.drink_recycler);
        drink_recyclerView.setLayoutManager(new LinearLayoutManager(this));
        drink_recyclerView.setHasFixedSize(true);
        PreferenceManager.getDefaultSharedPreferences(this).registerOnSharedPreferenceChangeListener(this);
        typeofdrink = PreferenceManager.getDefaultSharedPreferences(this).getString("key", "Non_Alcoholic");
        update(typeofdrink);


    }

    private void update(String type) {
        if (type.equals("favorites")) {
            Modelclass modelclass = ViewModelProviders.of(MainActivity.this).get(Modelclass.class);
            modelclass.getListLiveData().observe(this, new Observer<List<AlcoholPojo>>() {
                @Override
                public void onChanged(@Nullable List<AlcoholPojo> moviePojos) {

                    drink_recyclerView.setAdapter(new AlcoholAdapter(MainActivity.this, moviePojos));
                }
            });
        } else {
            string = alcoholUrl + type;
            AlcoholParsing alcoholParsing = new AlcoholParsing(string, MainActivity.this, drink_recyclerView);
            alcoholParsing.getAlcohol();
        }
    }

    @Override
    protected void onResume() {
        update(typeofdrink);
        super.onResume();
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String s) {
        typeofdrink = sharedPreferences.getString("key", "");
        Toast.makeText(this, getString(R.string.typeofdrink) + typeofdrink, Toast.LENGTH_SHORT).show();


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.drink_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_settiong) {
            Intent intent = new Intent(this, DrinkSettingsActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}
