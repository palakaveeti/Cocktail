package com.example.vignesh.cocktail.cocktailwidget;

import android.content.Intent;
import android.widget.RemoteViewsService;

public class CocktailRemoteViews extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new RemoteFactory(this.getApplicationContext());
    }

}
