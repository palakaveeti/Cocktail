package com.example.vignesh.cocktail.cocktailwidget;

import android.app.IntentService;
import android.content.Intent;
import android.support.annotation.Nullable;

public class CocktailService extends IntentService {


    public CocktailService() {
        super("iservice");
    }


    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        if (intent != null) {
            if (intent.getAction().equals("iservice")) {
                Intent i = new Intent("HomewigetAppTest", null, getApplicationContext(), CocktailWidget.class);
                i.setAction("HomewigetAppTest");
                sendBroadcast(i);
            }

        }
    }
}
