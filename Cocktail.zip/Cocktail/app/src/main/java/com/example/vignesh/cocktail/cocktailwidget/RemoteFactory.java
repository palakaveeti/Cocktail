package com.example.vignesh.cocktail.cocktailwidget;

import android.content.Context;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import static com.example.vignesh.cocktail.cocktailwidget.CocktailWidget.alcoholPojos;

import com.example.vignesh.cocktail.R;

class RemoteFactory implements RemoteViewsService.RemoteViewsFactory {
    Context context;

    public RemoteFactory(Context applicationContext) {
        context = applicationContext;
    }

    @Override
    public void onCreate() {

    }

    @Override
    public void onDataSetChanged() {

    }

    @Override
    public void onDestroy() {

    }

    @Override
    public int getCount() {
        return alcoholPojos == null ? 0 : alcoholPojos.size();

    }

    @Override
    public RemoteViews getViewAt(int i) {
        RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.cocktail_widget);
        remoteViews.setTextViewText(R.id.widgetlist, alcoholPojos.get(i).getName());
        return remoteViews;
    }

    @Override
    public RemoteViews getLoadingView() {
        return null;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }
}
