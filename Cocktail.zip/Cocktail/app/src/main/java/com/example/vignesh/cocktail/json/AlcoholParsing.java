package com.example.vignesh.cocktail.json;

import android.content.Context;
import android.support.v7.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.vignesh.cocktail.AlcoholAdapter;
import com.example.vignesh.cocktail.MainActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class AlcoholParsing {
    Context context;
    String url;
    RecyclerView recyclerView;
    ArrayList<AlcoholPojo> alcoholPojoList;
    AlcoholPojo alcoholPojo;

    public AlcoholParsing(String string, MainActivity mainActivity, RecyclerView drink_recyclerView) {
        context = mainActivity;
        url = string;
        recyclerView = drink_recyclerView;

    }

    public void getAlcohol() {
        alcoholPojoList = new ArrayList<>();
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    JSONArray main = object.getJSONArray("drinks");
                    for (int i = 0; i <= main.length(); i++) {
                        JSONObject list = main.getJSONObject(i);
                        alcoholPojo = new AlcoholPojo();
                        String drinkName = list.getString("strDrink");
                        String drinkImage = list.getString("strDrinkThumb");
                        String drinkId = list.getString("idDrink");
                        alcoholPojo.setName(drinkName);
                        alcoholPojo.setImage(drinkImage);
                        alcoholPojo.setId(Integer.parseInt(drinkId));
                        alcoholPojoList.add(alcoholPojo);

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                recyclerView.setAdapter(new AlcoholAdapter(context, alcoholPojoList));
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        requestQueue.add(stringRequest);

    }
}
