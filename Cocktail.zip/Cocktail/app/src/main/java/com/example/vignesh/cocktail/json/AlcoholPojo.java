package com.example.vignesh.cocktail.json;

import android.annotation.SuppressLint;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;

@Entity(tableName = "vignesh")
@SuppressLint("ParcelCreator")
public class AlcoholPojo implements Parcelable {
    @PrimaryKey
    @NonNull
    int id;
    String Image;
    String Name;

    protected AlcoholPojo(Parcel in) {
        id = in.readInt();
        Image = in.readString();
        Name = in.readString();
    }

    public AlcoholPojo() {

    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(Image);
        dest.writeString(Name);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<AlcoholPojo> CREATOR = new Creator<AlcoholPojo>() {
        @Override
        public AlcoholPojo createFromParcel(Parcel in) {
            return new AlcoholPojo(in);
        }

        @Override
        public AlcoholPojo[] newArray(int size) {
            return new AlcoholPojo[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }
}
