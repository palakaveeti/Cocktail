package com.example.vignesh.cocktail.json;

import android.content.Context;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.vignesh.cocktail.DetailActivity;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class DetailParsing {
    List<DetailPojo> detailPojoList;
    ImageView detailImage;
    TextView Name, Category, iba, typeofdrink, glass, instructions, manufatureddate;
    String urld;
    Context context;

    public DetailParsing(String detailurl, DetailActivity detailActivity, ImageView detailImage, TextView name, TextView category, TextView typeofdrink, TextView glass, TextView instruction, TextView manufatureddate, TextView iba) {
        urld = detailurl;
        context = detailActivity;
        this.detailImage = detailImage;
        Name = name;
        Category = category;
        this.iba = iba;
        this.typeofdrink = typeofdrink;
        this.glass = glass;
        this.instructions = instruction;
        this.manufatureddate = manufatureddate;

    }

    public void getDetails() {
        detailPojoList = new ArrayList<>();
        StringRequest stringRequest = new StringRequest(Request.Method.GET, urld, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("drinks");
                    for (int i = 0; i <= jsonArray.length(); i++) {
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        String Namee = jsonObject1.getString("strDrink");
                        String Categoryy = jsonObject1.getString("strCategory");
                        String ibaa = jsonObject1.getString("strIBA");
                        String drinktype = jsonObject1.getString("strAlcoholic");
                        String glasss = jsonObject1.getString("strGlass");
                        String instruction = jsonObject1.getString("strInstructions");
                        String manufatured = jsonObject1.getString("dateModified");
                        String image = jsonObject1.getString("strDrinkThumb");
                        Name.setText(Namee);
                        Category.setText(Categoryy);
                        typeofdrink.setText(drinktype);
                        glass.setText(glasss);
                        instructions.setText(instruction);
                        manufatureddate.setText(manufatured);
                        iba.setText(ibaa);
                        Picasso.with(context).load(image).into(detailImage);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        RequestQueue queue = Volley.newRequestQueue(context);
        queue.add(stringRequest);
    }

}

