package com.example.vignesh.cocktail.json;

import android.os.Parcel;
import android.os.Parcelable;

public class DetailPojo implements Parcelable {
    String name;
    String category;
    String iba;
    String alcoholicornot;
    String glass;
    String instructions;
    String image;
    String manufaturedDate;

    protected DetailPojo(Parcel in) {
        name = in.readString();
        category = in.readString();
        iba = in.readString();
        alcoholicornot = in.readString();
        glass = in.readString();
        instructions = in.readString();
        image = in.readString();
        manufaturedDate = in.readString();
    }

    public static final Creator<DetailPojo> CREATOR = new Creator<DetailPojo>() {
        @Override
        public DetailPojo createFromParcel(Parcel in) {
            return new DetailPojo(in);
        }

        @Override
        public DetailPojo[] newArray(int size) {
            return new DetailPojo[size];
        }
    };

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getIba() {
        return iba;
    }

    public void setIba(String iba) {
        this.iba = iba;
    }

    public String getAlcoholicornot() {
        return alcoholicornot;
    }

    public void setAlcoholicornot(String alcoholicornot) {
        this.alcoholicornot = alcoholicornot;
    }

    public String getGlass() {
        return glass;
    }

    public void setGlass(String glass) {
        this.glass = glass;
    }

    public String getInstructions() {
        return instructions;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getManufaturedDate() {
        return manufaturedDate;
    }

    public void setManufaturedDate(String manufaturedDate) {
        this.manufaturedDate = manufaturedDate;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(name);
        parcel.writeString(category);
        parcel.writeString(iba);
        parcel.writeString(alcoholicornot);
        parcel.writeString(glass);
        parcel.writeString(instructions);
        parcel.writeString(image);
        parcel.writeString(manufaturedDate);
    }
}
