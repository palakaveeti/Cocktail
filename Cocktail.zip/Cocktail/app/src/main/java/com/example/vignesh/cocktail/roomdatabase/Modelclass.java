package com.example.vignesh.cocktail.roomdatabase;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.content.Context;
import android.support.annotation.NonNull;

import com.example.vignesh.cocktail.json.AlcoholPojo;

import java.util.List;

public class Modelclass extends AndroidViewModel {
    LiveData<List<AlcoholPojo>> listLiveData;
    Context context;

    public Modelclass(@NonNull Application application) {
        super(application);
        RoomData data = RoomData.getDrinkData(this.getApplication());
        listLiveData = data.mydao().getData();
    }

    public LiveData<List<AlcoholPojo>> getListLiveData() {
        return listLiveData;
    }
}
