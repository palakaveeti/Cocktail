package com.example.vignesh.cocktail.roomdatabase;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.example.vignesh.cocktail.json.AlcoholPojo;

import java.util.List;

@Dao
public interface Mydao {
    @Insert
    void insertDrink(AlcoholPojo myFavourites);

    @Query("select * from vignesh")
    LiveData<List<AlcoholPojo>> getData();

    @Query("select * from vignesh where id= :id")
    AlcoholPojo selectedDrinkDat(int id);

    @Query("delete from vignesh where id = :id")
    void deleteDrinkData(int id);

    @Delete
    void deleteAllDrinks(AlcoholPojo myFavourites);
}
