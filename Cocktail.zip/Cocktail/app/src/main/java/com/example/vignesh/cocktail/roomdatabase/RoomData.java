package com.example.vignesh.cocktail.roomdatabase;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

import com.example.vignesh.cocktail.json.AlcoholPojo;

@Database(entities = {AlcoholPojo.class}, version = 5, exportSchema = false)
public abstract class RoomData extends RoomDatabase {
    public abstract Mydao mydao();

    private static RoomData roomData;

    public static RoomData getDrinkData(Context context) {
        if (roomData == null) {
            roomData = Room.databaseBuilder(context.getApplicationContext(), RoomData.class, "vigneshData")
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries()
                    .build();
        }
        return roomData;
    }
}
